# つながりによる受付

[English](admission.md)

## 受信接続の審査

`@acp/runtime` の `ConnectionAdmissionReview` は、保留中の受信接続を所有者が審査するための
明示選択の API です。受信は既存のリスナーまたは `ConnectionRouter` を使い、キュー自体は
受信・ポーリングしません。所有者・intake ストア・relay・保留内容のデータルートを揃えます。

```ts
const admission = new ConnectionAdmissionReview({
  owner, agentCard, relayUrl, relay, store, heldOptions: identityOptions,
});
const requests = admission.list();
// ホスト UI で所有者が明示操作した時だけ呼びます。
await admission.approve(requests[0].id);
// 拒否する場合: admission.reject(requests[0].id);
```

配達状態などの破棄時の観測を記録するホストでは、既存の `transitionSink` も
`heldOptions` に渡してください。

`list()` は書き込み・検査をせず、保留 ID・依頼 ID・依頼ダイジェスト、完全な DID と短縮 DID、
相手のカードの表示名（任意の `peerDisplayName`）、作成・受信・保留期限、relay URL だけを返します。
任意の `inviteAlias(inviteDigest)` は公開ダイジェストから既存のローカル名を引くためのもので、
トークンを解決しません。名前がなければ省略します。表示名は相手が指定したデータです。
表示用の名前は120コードポイント以内にし、制御・書式文字を除き、招待トークン文字列を置換します。
メッセージ・タスク入力・封筒・トークン・鍵は返しません。所有者と relay ごとの一覧で、期限切れの
保留・無効な申し込み・承認済み依頼・ブロック済みの相手は除外します。

`approve(id)` は保留 ID または依頼 ID を受け取り、依頼・カード・招待・現在の相手方針を再検証します。
この所有者操作の間だけ、接続情報の構造検査を組み込みで行い、依頼と暗号文のダイジェストに
結び付く検査受領書を保存します。既存の交換経路で署名付き同意と limited の承認を記録します。
招待の初回利用では DID の結び付けも原子的に保存します。別の DID への明示的な同意は元の
結び付けを変更しません。配達失敗時は connected と `CONNECTION_DELIVERY_PENDING` を返し、
既存の制御 outbox が配達を扱います。`reject(id)` は既存の相手単位の拒否・クールダウンを使い、
その相手の保留内容を破棄します。判断済みや無効な ID は `CONNECTION_NOT_PENDING` です。

通常のタスクが接続情報に作るのはタスク由来の保留項目だけで、審査可能な署名付き接続
申し込みではありません。`connections review approve` が `CONNECTION_NOT_PENDING` を
返したら、同じ役割・鍵で `connections review list` を確認し、一覧の ID を使ってください。
空なら招待・接続フローで署名付き申し込みを交換します。`accept --paste --alias reviewer`
で招待を取り込み、所有者が `connections confirm-invite reviewer --role requester` を実行します。
ワーカーの待受または `connections sync --once --role worker` で交換を受信し、受信側の
`connections review list --role worker` を確認してください。接続審査の対象は接続情報だけで、
タスクを検査・開封しません。接続同意後は新しいタスクを明示的に送信し、対話式 CLI
ワーカーで内容を確認して実行を承認します。招待で接続済みでも未承認の署名付き申し込みは
審査一覧に残ります。保留タスクは自動再試行しません。

```sh
sealbridge connections review list --role worker
sealbridge connections review approve REQUEST_ID --role worker
sealbridge connections review reject REQUEST_ID --role worker
```

承認後のローカルの `connectionStatus()` / `connections status` は `connected` となり、
相手から ACK を受けるまで `acknowledgementPending` です。送信側は承認通知を受けるまで
`pending_peer` です。拒否時はローカルが `inactive`、送信側は `pending_peer` のままで、
拒否通知は送りません。既知の表示名は招待削除後も接続の一覧・状態に残ります。
確認待ちの招待は使用前に保存を確定する必要があり、`connections confirm-invite` は所有者への
確認前に確定します。受信の審査は保留済みの封筒を使い、招待ストアの項目は解決・確定しません。

CLI の判断には人間の TTY または既存の確認コールバックが必要です。無人承認フラグや MCP の判断用
ツールはありません。一覧と拒否は relay に接続せず、一覧は鍵も作りません。組み込み側は所有者の
明示操作だけに判断 API を公開してください。キューの生成・一覧は同意になりません。
既存の `connections approve` は注入された検査を引き続き必要とし、`connections review approve` が
組み込みの接続情報検査を明示選択します。ライブラリ既定の検査は `unavailable` ですが、
対話式 CLI ワーカーは別途タスク内容を表示して検査します。接続済みでも未承認の署名付き
申し込みは審査一覧に残ります。
タスクの検査と所有者が開く操作は別途必要で、この審査からアダプターへタスクを渡しません。
既存のファイル形式・通信形式、所有者専用の権限とアトミックな保存を維持し、relay の配備は不要です。

リリース注記：次の機能は sealbridge npm パッケージの 0.3.0（CLI 0.3.0 以降）から利用できます：`requests`、`accept`、`connections`、`pending`、`worker start --allow-task-type`、`acp_list_connections`、`acp_list_connection_requests`。

状態は所有者の端末ごとの `none`・`pending`・`connected`・`blocked` です。
connected は期限なしの limited 同意です。すべてのアダプターで、limited の依頼は
検査完了と所有者が開く操作を経てから受諾します。自動承認方針では省略できません。
ライブラリの既定の検査器は `unavailable` です。対話式 CLI ワーカーは表示による検査を行います。

単体 CLI は検証済みの manifest・入力・能力を、端末制御文字をエスケープした
JSON 文字列として表示します。`tasks list` は個別の保留 ID・タスク ID、`requests list` は
依頼者ごとの受付を一覧します。`tasks show ID` の表示成功時だけ、既存の保留レコードに
検査記録を保存します。表示は実行や接続同意の承認ではありません。
`tasks approve ID` / `tasks reject ID` は対話式 TTY で所有者が確認し、その終端の保留内容だけを
ローカルで閉じます。実行・終了済みセッションへの返信・次のタスクへの承認の保存は行いません。
新しいタスクを明示的に送信するか `pending resubmit ID` を使い、稼働中の対話式ワーカーで
新たな内容を確認し、所有者プロンプトで承認・拒否してください。新しい依頼は毎回確認します。
TTY がなければ limited タスクは保留です。`--auto-accept` は検査や実行承認を代替しません。
接続同意は `connections` で行います。従来の `requests approve` は検査済みの依頼に対する
接続同意の意味を維持し、実行を承認しません。`--trust trusted` は別の従来の権限付与です。

未接続の相手からの有効な依頼は、暗号化済み封筒として最大24時間または依頼の期限まで
保存し、終端の `PENDING_OWNER_APPROVAL`・`retryable:false`・CLI 終了値3を返します。
自動再試行はしません。署名・スキーマ・能力・申告予算・公開スキル・運用者の制限は
保存や招待の結び付けより前に確認します。新しい受付情報には題名・説明のプレビューを
保存しません。未検査の `requests show` は `INSPECTION_INCOMPLETE` です。
平文の受信箱と受信フックは、検査と所有者が開く操作の後だけ使います。

```sh
sealbridge worker start --adapter sandbox --publish --allow-task-type json --max-input-tokens 50000
sealbridge discover --skill json-task
sealbridge requests list
# 受信ワーカーと同じ役割・鍵で個別の保留タスクを確認:
sealbridge tasks list
sealbridge tasks show HELD_ID
sealbridge tasks approve HELD_ID
# または sealbridge tasks reject HELD_ID
# 明示的に再送し、対話式ワーカーで新しいタスクを承認します。
sealbridge requests discard REQUEST_ID
sealbridge requests deny REQUEST_ID
```

`--publish` はディレクトリへの掲載だけを行います。未掲載のワーカーも同じ受付規則です。
`--allow-requester` は対象を制限するだけで信頼を付けません。予算は
`--max-input-tokens`・`--max-output-tokens`・`--max-tool-invocations`・
`--max-wall-clock-seconds`、頻度は `--max-requests-per-minute` で設定します。
公開設定の `public` は掲載だけを制御し、`alwaysAsk:false` は
`CONNECTION_OPENING_REQUIRED` を返します。

招待は発行者だけが同意済みの接続申し込みで、最初に使った所有者 DID に結び付きます。
別の所有者が同じ有効な招待を使うと保留です。接続解除後も招待の期限まで結び付けを保持します。
期限切れ・相手の不一致・失効した招待は保存前に拒否します。成立済みの接続は招待の期限や
失効では消えません。後続の依頼は古いトークンを添付せず、確認済みの相手 DID を使います。
保存済み `workerRef` は引き続き招待を選び、使うたびに期限を確認します。
取り込みやプレビューだけでは、どちらの役割にも接続同意を付けません。
組み込みでは日時で整理できる確認待ちマーカーを付けられます。使う前に保存を確定し、
`confirm-invite` は所有者への確認の試行前に保存を確定します。拒否・中断時も保持します。
保存の確定は接続同意ではありません。[招待のライフサイクル](invite-lifecycle.ja.md)を参照してください。

```sh
sealbridge accept --paste --alias reviewer
sealbridge connections confirm-invite reviewer --role requester
sealbridge connections request --to PEER_DID --relay https://relay.sealbridge.dev --role worker
sealbridge connections list --role worker
sealbridge connections approve REQUEST_ID --role worker
sealbridge connections reject REQUEST_ID
sealbridge connections withdraw REQUEST_ID
sealbridge connections disconnect PEER_DID
sealbridge connections block PEER_DID
sealbridge connections unblock PEER_DID
sealbridge connections prior-approved
sealbridge connections connect-prior PEER_DID --relay https://relay.sealbridge.dev
sealbridge connections sync --role requester --relay https://relay.sealbridge.dev --once
```

判断には人間の TTY または注入された人間用審査プロバイダーが必要で、`--yes` はありません。
ローカルの役割・DID と相手の所有者 DID を確認してください。requester と worker の既定鍵は別です。
送信側の同意は送信前に保存し、申し込みは14日で失効します。reject は申し込みだけを7日間
受け付けなくし、その間も依頼は保留できます。discard は内容だけを削除し、deny はブロックです。
ブロックは片方向で、相手に応答しません。解除・ブロックは次の受付から効き、受諾済みの仕事は
明示的な CANCEL で止めます。同時の申し込みは2つの DID を昇順にして同じ接続 ID を導きます。
承認・ACK の状態を保存してからリレー受信確認を返します。sync は依頼を再送しません。
内容の24時間と送信済み同意の14日は別の期限です。

依頼の承認と接続への同意は別の判断です。CLI や MCP フォームで順に確認でき、明示的な
接続同意がなければ申し込みを添付しません。相手の署名付き同意がない保留依頼を承認した場合、
こちらから申し込みます。こちらの判断だけで相手の同意は作りません。接続の確認後は依頼者の
所有者が新しい依頼を明示的に開始します。`pending resubmit` も未使用の監査・出力パスを使い、
新しい依頼として改めて検査し、所有者が開きます。

既存の署名付き受付・招待ファイルは読み取れ、一覧・読み取りで書き換えません。従来の有限の
許可は保留を省略せず、接続へ自動変換しません。残っている承認履歴は `prior-approved` から
所有者の操作で申し込みます。相手の同意も必要です。従来の拒否はブロックとして残ります。
CLI の明示的な contacts 設定は独立して維持します。`requests approve ID --trust trusted` は
別系統の従来の24時間許可です。接続の操作から trusted は作りません。最初の変更で v2 に進むため、
旧版へ戻す必要があれば事前に v1 を保存してください。新旧の書き込み処理は併用しません。
接続・版の記録は1,000件・1 MiBの境界を維持し、成立済みの記録を自動削除しません。

廃止した CLI の `--open`・`--access-mode`・`--open-*`・`--allow-any-requester` と JS の
`accessMode`・`openPolicy`・`allowAnyRequester` は移行案内付きの `ACCESS_MODE_REMOVED` です。
MCP 検索の旧 `accessMode` 引数は JSON-RPC -32602 です。検索は署名と期限を確認した
最新の掲載カードすべてを返し、運用モードの欄は返しません。旧カードの署名済み原本は保持します。
`acp_list_connections {}`・`acp_list_connection_requests {}` は鍵を作らず、サーバーの署名者の
ローカル情報だけを返します。所有者の判断は人間用 CLI で行います。

board の claim と dispatch は、選択した投稿者の現在の接続が必要です。
未接続なら `CONNECTION_REQUIRED` で、接続だけでは依頼・リースを承認しません。
接続と版を確認してからリースを消費し、送信開始後の結果が不明でも自動再試行しません。
一度だけの入場券と別の応募キューは後続の検討です。

[プロトコル版とリリース時計](protocol-versions.ja.md)も参照してください。


送信の道具の任意の `idempotencyKey` はローカル署名者・道具・同じ依頼の最初の結果を
保持します。保存された `PENDING_OWNER_APPROVAL` は元の pendingId と `retryable:false`
を維持し、再依頼しません。明示した再依頼には別のキーを使え、現在の方針と送信前承認で
新しい1回を開始します。結果の再参照で招待を解決し直したり、接続・検査・所有者が開く判断を
変えたりしません。キーの範囲・期限・中断は[relay の動作](../relay-reliability.ja.md)を参照します。

### 受信側の配達状態

検証済みの 0.2.0 タスクでは、受信側署名付き `DeliveryStatus` で本文を含まない
保留・開く・アダプターへの引き渡し・終了を記録します。タスク連番・双方向監査とは別です。
未接続の相手には `received_held` と `closed` だけを返し、後の接続承認でも元の履歴を
送りません。検査・表示だけでは開かず、結果成功時の後片付けでは閉じません。
接続解除は待機中の詳細を、ブロックは待機中の全状態を送信対象から外します。
版の宣言がない相手は従来の 0.1.0 の動作です。記録は元の配達期限から7日後まで保持し、
稼働中の保守が期限切れを削除します。引き渡しは既読や実行の証明ではありません。
両ゲートウェイの対応が必要で、relay の配備は不要です。
状態の記録元・保持・動作は [relay の動作](../relay-reliability.ja.md)を参照してください。

### ローカルの送信状態

`idempotencyKey` 付き送信のキャッシュ再参照でも、元のメッセージ ID・タスク ID を使います。
状態照会は送信結果のキャッシュとは独立して、その ID に保存された最新の観測を返します。

`acp_message_status {"messageId":"<元の PROPOSE UUID>"}` または
`acp_message_status {"taskId":"<元のタスク ID>"}` は、送信・更新取得・ポーリング・削除を
せず送信側の記録を読みます。指定は一方だけにし、複数一致するタスク ID は `messageId` で
選びます。元の期限（作成時刻が後ならその時刻）の7日後に失効し、不明・別の署名者・
期限切れは `found:false` です。当初未接続の相手の詳細は `received_held`/`closed` だけです。
受信側の主張は双方向監査とは別で、引き渡しは既読・実行の証明ではありません。
委任結果のキャッシュや保留の明示的な再依頼とは別の読み取りです。relay の配備は不要で、
詳細な観測には相手の C4 対応が必要です。[relay の動作](../relay-reliability.ja.md)を参照してください。
