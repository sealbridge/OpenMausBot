# Held-content library boundary

[日本語](held-content.ja.md)

`@acp/runtime` exports `HeldRequestStore`, `HeldRequestReview`, and the injected
`HeldContentReviewProvider`. Runtime, CLI and board attach these interfaces to live admission. Inspection is unavailable by default; see [connections admission](admission.md).

The store retains original encrypted signed envelopes with owner-signed metadata
under `<dataRoot>/quarantine/<sha256-local-owner-DID>/<id>.json`; summaries omit
input, titles and descriptions. The default provider returns `unavailable`, so
content remains held. No inspection rules, detectors or subprocess are included.
`hold`, `inspect`, `showReviewedContent`, `discard`, and `expire` are library APIs.
Content display requires a completed receipt bound to the owner, kind, content,
envelope and report digests; it does not approve execution or connection consent.
Task digests use `digest({manifest,input})`; connection and reserved application
digests cover the entire decrypted body. Inspection timeout defaults to 5 seconds;
errors, timeout and unavailable results leave content held.

Hosts authorize owner review, validate sender-owner delegation and deadlines,
acknowledge only after `hold` succeeds, schedule `expire`, call `discardPeer` on
block, discard offers after decisions and tasks after result transmission. Reads
leave files intact. Retention is the earlier of the deadline and 24 hours. Bounds:
100 records, 256 KiB per envelope, 32 MiB of envelopes, plus 8 KiB metadata per
record; live records are not evicted. POSIX paths use 0700/0600; Windows inherits
the parent DACL without ACL verification. Supply `workspaceDir` when known to
reject storage within an adapter workspace. Custom providers remain host integrations. The standalone CLI supplies built-in
owner-facing task display: `tasks list/show/approve/reject` select individual held
tasks; interactive workers display each fresh task before their live owner gate.
Display validates the signed proposal, manifest, recipient and content digest and
renders manifest/input/capabilities as literal JSON with terminal controls escaped.
Only successful rendering returns completion to `HeldRequestReview.inspect`, which
signs the existing v1 `HeldContentInspection` receipt in the existing held record.
Its report digest is `digest({type:'CliTaskDisplay',v:1,contentDigest})`. This means
validated content was rendered, not automated assessment or owner consent. Failed,
interrupted or unavailable display does not record completion. Cached receipts do
not replace display in a new owner operation. No storage format changes are needed.
Terminal held approve/reject closes only the selected ciphertext locally; it stores
no execution approval. A fresh task needs new inspection and live owner approval.
The library default provider and non-interactive workers remain unavailable.
Connection metadata review remains separate.

Gateway task sends use a signer-scoped persistent envelope outbox and worker receipt/default
checkpoint records under `<data-root>/delivery/<sha256-local-signer-DID>/`. A repeated
proposal does not authorize another adapter invocation. Inspection and owner opening
remain required on their existing paths. Pending review terminates the delegation call;
outbox retries do not resubmit it. Ciphertext retry ends at relay admission or the original
deadline, and a stopped gateway waits for restart. See [relay reliability](../relay-reliability.md).

### Recipient delivery status

Recipient-signed `DeliveryStatus` for validated 0.2.0 tasks records content-free
held/opened/adapter-handoff/closed observations separately from task sequences and
bilateral audit. Unknown peers get only `received_held` and `closed`; later connection
approval does not release that task's history. Inspection/display alone does not open
a task, and successful result cleanup does not close it. Queued detail is suppressed
on disconnect; blocking suppresses all queued status. Legacy peers without version
declarations retain 0.1.0 behavior. Status records use the fixed delivery deadline plus
seven days; active maintenance deletes expired bytes. A handoff does not prove reading
or execution. Both gateways need support; no relay deployment is required.
See [relay reliability](../relay-reliability.md) for status sources, retention and lifecycle behavior.
